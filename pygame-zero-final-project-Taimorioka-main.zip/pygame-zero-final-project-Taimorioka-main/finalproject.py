import os
import math
import random
import time

import pygame
import pgzrun
from pgzhelper import *

os.environ['SDL_VIDEO_WINDOW_POS'] = '0,0'

WIDTH = 1920
HEIGHT = 1080

left_wall = Rect(0, 0, 1, HEIGHT)
right_wall = Rect(WIDTH - 1, 0, 1, HEIGHT)
top_wall = Rect(0, 0, WIDTH, 1)

player = Actor("shooter")
player.pos = WIDTH // 2, HEIGHT // 2 + 450
player.angle = 90
player.scale = 5
angle = 0
shooterAngle = 0
listOfClones = []
animations = []
able_to_fire = True
num_bullets = 1
bulletidx = 4
gameOver = False
amount_of_rows = 11
listOfBoxes = []
tmer = 1
fps = 60
level = 1
turns_to_next_level = 3
def fpsfunc():
    global tmer, fps
    fps = tmer
    tmer = 0
    clock.schedule(fpsfunc, 1)
fpsfunc()
def update():
    global shooterAngle, tmer, num_bullets, listOfBoxes, listOfClones
    rotate_player_towards_mouse(player)
    shooterAngle = player.angle
    tmer += 1
    # Update bullet positions
    for bullet in listOfClones:
        # Calculate movement direction based on the bullet's angle
        move_x = math.cos(math.radians(90 - bullet.angle + 180))  # Adjusted angle
        move_y = math.sin(math.radians(90 - bullet.angle + 180))  # Adjusted angle

        # Move the bullet
        bullet.x += move_x * 10
        bullet.y += move_y * 10  # Since positive y is downward

        # Remove bullets that are off-screen
        if not 0 < bullet.y < HEIGHT or not 0 < bullet.x < WIDTH:
            listOfClones.remove(bullet)

        # Check for collisions with walls + bullets
        for boxes in listOfBoxes:
            if bullet.colliderect(boxes):
                if 135 > bullet.angle % 360 > 45 or 315 > bullet.angle % 360 > 225:
                    bullet.angle = -bullet.angle
                else:
                    bullet.angle = 180 + bullet.angle
                if boxes.hp == 1000:
                    num_bullets += 1
                    listOfBoxes.remove(boxes)
                else:
                    boxes.hp -= 1
                    if boxes.hp <= 0:
                        listOfBoxes.remove(boxes)
        if bullet.colliderect(left_wall) or bullet.colliderect(right_wall):
            bullet.angle = -bullet.angle  # Reverse the horizontal direction
        if bullet.colliderect(top_wall):
            bullet.angle = 180 - bullet.angle  # Reverse the vertical direction


def rotate_player_towards_mouse(player):
    global angle
    mouse_x, mouse_y = pygame.mouse.get_pos()
    angle = math.atan2(mouse_y - player.y, mouse_x - player.x)
    angle = math.degrees(angle) + 90
    player.angle = -angle


def draw():
    global level
    if not gameOver:
        global fps
        screen.fill("black")
        player.draw()
        for bullet in listOfClones:
            bullet.draw()
        for boexes in listOfBoxes:
            boexes.scale = 2
            boexes.draw()
            if boexes.hp != 1000:
                screen.draw.text(str(boexes.hp), color="white",center=(boexes.x,boexes.y), fontsize=20)
        screen.draw.text((f"You are at {fps} fps"), color = "white", topright = (WIDTH -20, 20), fontsize = 20)
        screen.draw.text((f"You are rendering {len(listOfClones)} bullets"), color = "white", topleft = (20, 20), fontsize = 20)
    else:
        screen.draw.text(f"Game Over! score = {level}", color="red", center=(WIDTH / 2, HEIGHT / 2), fontsize=60)


def createBullet():
    global listOfClones, shooterAngle
    bullet = Actor("bullet")
    bullet.scale = 3
    bullet.pos = player.pos
    bullet.angle = player.angle
    listOfClones.append(bullet)


def createBoxes():
    global listOfBoxes, amount_of_rows, level, num_bullets
    listofsmallbox = []
    for x in range(amount_of_rows):
        rand = random.randint(0, 3)
        if rand == 0:
            extra = Actor("extra-ball")
            extra.hp = 1000
            listofsmallbox.append(extra)
        elif rand == 1:
            extra = Actor("box")
            extra.hp = num_bullets
            listofsmallbox.append(extra)
        elif rand == 2:
            extra = Actor("box")
            extra.hp = random.randint(2, 10) * level
            listofsmallbox.append(extra)
        elif rand == 3:
            extra = Actor("box")
            extra.hp = random.randint(10, 25) * level
            listofsmallbox.append(extra)
    gapSize = WIDTH / (len(listofsmallbox) + 1)
    multiplyer = 0
    for box in listofsmallbox:
        multiplyer += 1
        x = gapSize
        box.x = (multiplyer * x)
        box.y = HEIGHT - 980
        listOfBoxes.append(box)


def advance():
    global gameOver
    for boxs in listOfBoxes:
        boxs.y += 30
        if boxs.y  > HEIGHT // 2 + 450:
            gameOver = True
    createBoxes()

def on_mouse_down(pos):
    global able_to_fire, num_bullets, level, turns_to_next_level
    if not turns_to_next_level:
        level += 1
    else:
        turns_to_next_level -= 1
    if able_to_fire and not gameOver:
        for x in range(num_bullets):
            clock.schedule(createBullet, 0.01 * x)
        advance()

pgzrun.go()